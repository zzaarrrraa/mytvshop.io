from django.urls import path
from .views import register, auth, logout

urlpatterns = [
    path('register', register, name='register'),
    path('auth', auth, name='auth'),
    path('logout', logout, name='logout')
]