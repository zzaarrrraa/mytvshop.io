from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, get_user_model, logout as log_out

User = get_user_model()

def register(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        username = request.POST["username"]
        password = request.POST["password"]
        User.objects.create_user(first_name=first_name, username=username, password=password)
        return redirect("auth")
    return render(request, 'users/register.html')

def auth(request):
    error = ''
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect("main")
        else:
            error = "Неверный логин или пароль"

    return render(request, 'users/auth.html', {'error' : error})

def logout(request):
    log_out(request)
    return redirect("main")
