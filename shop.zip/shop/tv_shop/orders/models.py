from django.db import models
from django.contrib.auth import get_user_model
from .models import Product

User = get_user_model()

class Order(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name='Пользователь') # Один к одному
    created = models.DateTimeField(auto_now_add=True, verbose_name='Дата добавления')

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='Товар') # Один ко многим
    price = models.IntegerField(verbose_name='Цена товара')
    quantity = models.IntegerField(verbose_name='Количество')
     


