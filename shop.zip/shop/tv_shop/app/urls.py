from django.urls import path
from .views import main, catalog, contacts, product, basket
from .api import add_product
from . import views

urlpatterns = [
    path('', main, name='main'),
    path('catalog', catalog, name='catalog'),
    path('contacts', contacts, name='contacts'),
    path('product/<int:product_id>', product, name='product'),
    path('basket', basket, name='basket'),
    path('add_product', add_product, name='add_product'),
    path('remove_from_basket/<int:basket_item_id>/', views.remove_from_basket, name='remove_from_basket')
]