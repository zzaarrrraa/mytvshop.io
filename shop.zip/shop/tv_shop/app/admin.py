from django.contrib import admin
from .models import Product, Basket, BasketItems

admin.site.register(Product)
admin.site.register(Basket)
admin.site.register(BasketItems)

