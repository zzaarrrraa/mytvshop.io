const product = document.querySelector("button")
const price_number = document.querySelector(".price_number")
const token = document.querySelector('input[name="csrfmiddlewaretoken"]')

product.addEventListener('click',  () => {
    const quantity = document.querySelector(".quantity").value
    const productId = product.id
    const productPrice = price_number.textContent
    const formData = new FormData()
    formData.append('quantity', quantity)
    formData.append('productId', productId)
    formData.append('productPrice', productPrice)
    formData.append('csrfmiddlewaretoken', token.value)
    fetch('http://127.0.0.1:8000/add_product', {method:"post", body: formData})
    .then(result => result.json())
    
})

document.addEventListener("DOMContentLoaded", function () {
    const buyButton = document.querySelector('.buy_button');
    const notification = document.getElementById('notification');
    
    buyButton.addEventListener('click', function () {
        notification.style.display = 'block';
        setTimeout(function () {
            notification.style.display = 'none';
        }, 5000);
    });
});
