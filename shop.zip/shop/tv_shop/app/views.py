from django.shortcuts import render, redirect
from .models import Product, BasketItems, Basket

def main(request):
    products = Product.objects.all()
    return render(request, 'app/main.html', {'products' : products})

def catalog(request):
    products = Product.objects.all()
    return render(request, 'app/catalog.html', {'products' : products})

def contacts(request):
    return render(request, 'app/contacts.html')

def product(request, product_id):
    product = Product.objects.get(id=product_id)
    return render(request, 'app/product.html', {'product' : product})

def basket(request):
    user = request.user
    basket = Basket.objects.filter(user=user)
    basket_items = BasketItems.objects.filter(basket=basket[0])
    return render(request, 'app/basket.html', {"basket_items" : basket_items})

def remove_from_basket(request, basket_item_id):
    try:
        basket_item = BasketItems.objects.get(id=basket_item_id)
        basket_item.delete() 
    except BasketItem.DoesNotExist:
        pass 
    
    return redirect('basket') 



