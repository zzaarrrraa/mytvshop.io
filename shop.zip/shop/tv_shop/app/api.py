from django.http import JsonResponse
from .models import Basket, BasketItems, Product

def add_product(request):
    quantity = request.POST["quantity"]
    price = request.POST["productPrice"]
    product_id = request.POST["productId"]
    user = request.user
    basket = Basket.objects.filter(user=user)
    product = Product.objects.filter(id=product_id)
    if basket:
        check_product = BasketItems.objects.filter(basket=basket[0], product=product[0])
        if check_product:
            check_product.update(quantity = check_product[0].quantity + 1)
        else:
            basketItems = BasketItems.objects.create(basket=basket[0], product=product[0], price=price, quantity=quantity)
    else:
        basket = Basket.objects.create(user=user)
        basketItems = BasketItems.objects.create(basket=basket, product=product[0], price=price, quantity=quantity)
    return JsonResponse({"success" : True})
    