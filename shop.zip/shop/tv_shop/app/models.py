from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Product(models.Model):
    title = models.CharField(max_length=100)
    discription = models.TextField()
    price = models.IntegerField()
    image = models.ImageField(upload_to='images/')
    created = models.DateTimeField(auto_now_add=True)
    counts = models.IntegerField(default=0)

    def __str__(self):
        return self.title

class Basket(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name='Пользователь') # Один к одному
    created = models.DateTimeField(auto_now_add=True, verbose_name='Дата добавления')

class BasketItems(models.Model):
    basket = models.ForeignKey(Basket, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='Товар') # Один ко многим
    price = models.IntegerField(verbose_name='Цена товара')
    quantity = models.IntegerField(verbose_name='Количество')

